/*Вывод таблицы умножения для определенного числа в массив, каждый элемент массива в виде: 
число * итератор = результат. Для формирования строки используйте интерполяцию.*/

/*const userInput = prompt("Введите целое число от 1 до 10: ");
let number = parseFloat(userInput);
if (Number.isInteger(number) && number > 0 && number <= 10 && number % 1 ===0) {
let multiplicationArr = [];
let i = 1;
while(i <= 10) {
    let result = number * i;
    let row = `${number} * ${i} = ${result}`;
    multiplicationArr.push(row);
    i++;
}
console.log(multiplicationArr);
} else {
console.log("Вы ввели неправильное число, попробуйте снова")
userInput = prompt("Введите значение от 1 до 10: ");
}*/

/*Поиск первого положительного числа в массиве: 
есть массив чисел и нужно найти первое число, 
которое является положительным.*/

/*const arra = [-6, -5, 3, 56, -6 ];
let i = 0;
let fPos;
while (i < arra.length) {
if (arra[i] > 0) {
fPos = arra[i];
break;
}
  i++;
}
console.log(fPos);*/


/*Генерация случайного пароля: 
есть некая константа, которая отвечает за длину пароля. 
Сгенерируйте рандомный пароль до указанной длины, 
используя Math.random:
*/
/*const length = 12;
const symbols = '0123456789abcdefghijklmnopqrstuvwxyz';
let password = '';
let i = 0;
while (i < length) {
  const random = Math.floor(Math.random() * symbols.length);
  password += symbols.charAt(random); 
  i++;
}
console.log(password);*/



/*Объединение элементов массива в строку 
при помощи конкатенации: есть массив строк 
(например, список покупок) - необходимо вывести его в виде строки.
*/
/*const array = ['хлеб', 'минералка', 'чипсы', 'пиво','мясо'];
let result = '';
for (let i = 0; i < array.length; i++) {
result += array[i];
if (i !== array.length) {
result += ', '
}
}
console.log(result);*/

/*Поиск наибольшего числа в массиве
 */
/*
const numArr = [18, 26, 9, 16, 19, 7];
let maxNumber = numArr[0];
for (let i = 0; i < numArr.length; i++) {
if (numArr[i] > maxNumber) {
maxNumber = numArr[i];
}
}
console.log(maxNumber);*/


/*Переворот строки: есть некая константа,содержащая строку. 
Необходимо вывести строку наоборот, используя цикл for
 */

/*const str = '!Guten morgen Deutschland!';
let newString = '';
for (let i = str.length - 1; i >= 0; i--) {
newString += str[i];
}
console.log(newString);*/


//Подсчет количества гласных букв в строке: есть строка и массив гласных в алфавите (можно выбрать английский). 
//Необходимо посчитать, сколько раз встречаются гласные в этой строке. 
//Методы для решения этой задачи Вы найдете в файлике к уроку.

/*const string ="Hello world, i am a student, my name is Anton.";
const aaaArr = ['a', 'e', 'i', 'o', 'u', 'y'];
let letter = 0;
for (i = 0; i < string.length; i++) {
let lowCase = string.toLowerCase();
if (aaaArr.includes(lowCase[i])){
letter++;
}
}
console.log("Количество гласных букв в предложении:" + letter);*/

//Напишите функцию, которая принимает массив чисел и возвращает их сумму.

/*const array = [12, 23, 45, -256, 153, 65];
let summe = 0;
function sum(sumArray) {
for (let i=0; i < array.length; i++) {
summe += array[i];
}
console.log('Сумма элементов массива:' +  summe);
}
sum();*/

//Напишите функцию findMax, которая принимает массив чисел и возвращает максимальное число из этого массива.

/*const arr = [2, 65, 78, 6, 10, 153];
let maxNumber = arr[0];
function findMax(maxNum) {
for (let i=0; i < arr.length; i++){
if(arr[i] > maxNumber) {
    maxNumber = arr[i];
}
}
console.log("Максимальное число из массива :" + maxNumber);
}
findMax();*/

//Напишите функцию reverseArray, которая принимает массив и 
//возвращает новый массив, в котором элементы идут в обратном порядке.
/*
let revArr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
function reverseArray(reverseArr) {
     const iArr = [];
     for (let i = reverseArr.length - 1; i >= 0; i--) {
         iArr.push(reverseArr[i]);
     }
       console.log(iArr);
     return iArr;
 }
 reverseArray(revArr);
*/


//Напишите функцию, которая принимает массив строк и возвращает новый массив, 
//содержащий только строки, начинающиеся с заданной буквы.

/*
function sortStringsByLetter(arrStrings, letter) {
let sortedStrings = [];
for (let i = 0; i < arrStrings.length; i++) {
    let currentString = arrStrings[i];
    if (currentString.charAt(0) === letter) {
         sortedStrings.push(currentString);
     }
 }
 return sortedStrings;
 }

 let strings = ["Напишите", "функцию", "которая", "принимает", "массив", "содержащий", "буквы"];
 let letterM = "m";
 let filtered = sortStringsByLetter(strings, letterM);
 console.log("Source array:", strings);
 console.log(`Lines beginning with "${letterM}":`, filtered);
*/

//Напишите функцию, которая принимает число и возвращает его факториал.
/*
function faktoreal(n) {
if (n === 0 || n === 1) { 
return 1;
} else {
  return n * faktoreal(n - 1);
}
}
let numb = 6;
let fakToReal = faktoreal(numb);
console.log(fakToReal);
*/

//Напишите функцию, которая принимает число и возвращает "Fizz", 
//если число делится на 3, "Buzz", если число делится на 5, и "FizzBuzz", 
//если число делится и на 3, и на 5. В остальных случаях вернуть само число.

/*
function fizBuz (hz){
if (hz % 3 === 0 && hz % 5 === 0) {
  let fizzBuzz = 'FizzBaZZ';
  return fizzBuzz;
}
if(hz % 3 === 0) {
  let fizz = 'Fizz';
  return fizz;
}
if (hz % 5 === 0) {
  let bazz = 'Buzz';
  return bazz;
} else {
  return hz;
}
}
let abc = fizBuz(15);
console.log(abc); 
*/

//Создайте функциональное выражение calculateCircleArea, 
//которое принимает объект circle с свойством radius и возвращает площадь круга.
/*
let circle = {
  radius : 5
}

let calculateCircleArea = function fun(params) {
  let f = params.radius ** 2 * Math.PI;
  return f.toFixed(1); 
}
console.log(calculateCircleArea(circle));*/



//Создайте функциональное выражение calculateAverageGrade, 
//которое принимает объект student с массивом оценок grades и возвращает среднюю оценку студента
// (попробуйте использовать reduce, описанный в файле предыдущего урока).
/*
let student = {
  grades : [3, 3, 3, 4, 1, 2, 1]
}

let calculateAverageGrade = student.grades.reduce((acc, current) => acc + current, 0);
let grade = calculateAverageGrade / student.grades.length;
console.log("Средняя оценка студента:" + grade.toFixed(2));
*/

//Создайте функциональное выражение getFullName, 
//которое принимает объект person с свойствами firstName и lastName и возвращает полное имя.

/*
const perso = {
  firstName: "Anton",
  lastName: "Kiyashov"
}
let getFullName = function (person) {
return person.firstName + ' ' + person.lastName;
}
let fullName = getFullName(perso);
console.log(fullName);
*/

//Создайте объект calculator с двумя свойствами operand1 и operand2, 
//и двумя методами: add и multiply. Метод add должен принимать два числа и возвращать их сумму, 
//а метод multiply должен принимать два числа и возвращать их произведение.
/*
const calculator = {
  operand1: 6,
  operand2: 7,
  getAdd: function(){
    return this.operand1 + this.operand2
  },
  getMultiply: (num1, num2) => calculator.operand1 * calculator.operand2
};
console.log(calculator.getAdd());
console.log(calculator.getMultiply());*/

